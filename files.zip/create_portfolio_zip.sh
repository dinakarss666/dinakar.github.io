#!/usr/bin/env bash
set -euo pipefail

# Directory to build
TMP_DIR="portfolio-site"
ZIP_NAME="portfolio.zip"
B64_NAME="${ZIP_NAME}.b64"

rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR"
cd "$TMP_DIR"

# -- index.html
cat > index.html <<'HTML'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dinakar S — Electrical Engineering Portfolio</title>
  <meta name="description" content="Dinakar S — B.E. Electrical & Electronics Engineering student at PSG College of Technology. Projects: IoT motor control, pedal power generation. Contact: dinakarss666@gmail.com" />
  <meta name="author" content="Dinakar S" />
  <!-- Open Graph -->
  <meta property="og:title" content="Dinakar S — Electrical Engineering Portfolio" />
  <meta property="og:description" content="B.E. Electrical & Electronics Engineering student at PSG College of Technology — projects in IoT motor control and renewable energy." />
  <meta property="og:type" content="website" />
  <meta property="og:locale" content="en_IN" />
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>

  <header class="site-header" role="banner">
    <div class="header-inner">
      <div class="intro">
        <h1 class="site-title">Dinakar S</h1>
        <p class="subtitle">Electrical Engineering Student — PSG College of Technology</p>
        <p class="tagline">Driven by innovation, hands-on learning, and a passion for sustainable technology.</p>
        <div class="actions">
          <a class="btn" href="#projects">See Projects</a>
          <a class="btn outline" href="resume.pdf" download>Download Resume</a>
        </div>
      </div>

      <div class="photo-wrap" aria-hidden="false">
        <!-- Replace your-photo.jpg with your real photo -->
        <img src="your-photo.jpg" alt="Dinakar S portrait" class="profile-photo" />
      </div>
    </div>

    <nav class="site-nav" role="navigation" aria-label="Primary">
      <ul>
        <li><a href="#contact">Contact</a></li>
        <li><a href="#education">Education</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#experience">Experience</a></li>
        <li><a href="#projects">Projects</a></li>
      </ul>
    </nav>
  </header>

  <main id="main" class="site-main" role="main">
    <section id="contact" class="card">
      <h2>Contact</h2>
      <p>Email: <a href="mailto:dinakarss666@gmail.com">dinakarss666@gmail.com</a></p>
      <p>Phone: +91 9715376636</p>
      <p>Location: Namakkal, Tamil Nadu</p>
      <p>LinkedIn: <a href="#" target="_blank" rel="noopener">Your LinkedIn URL</a> · GitHub: <a href="#" target="_blank" rel="noopener">Your GitHub</a></p>

      <form id="contact-form" aria-label="Contact form">
        <label for="name">Name</label>
        <input id="name" name="name" required>

        <label for="email">Email</label>
        <input id="email" name="email" type="email" required>

        <label for="message">Message</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <div class="form-actions">
          <button type="submit" class="btn">Send</button>
          <button type="button" id="mailto-fallback" class="btn outline">Open Mail App</button>
        </div>

        <p id="form-note" class="muted">This form opens your mail client to send the message (no server required).</p>
      </form>
    </section>

    <section id="education" class="card">
      <h2>Education</h2>
      <ul>
        <li><strong>PSG College of Technology</strong> – B.E. Electrical & Electronics Engineering (CGPA: 7.58, Expected 2025)</li>
        <li><strong>Shri Vinayaga Higher Secondary School</strong> – XII: 80.6% (2020), X: 81.2% (2018)</li>
      </ul>
    </section>

    <section id="skills" class="card">
      <h2>Skills & Tools</h2>
      <ul class="skills-list">
        <li>Simulink</li>
        <li>Proteus</li>
        <li>Motorsolve</li>
        <li>Microsoft Excel / PowerPoint / Word</li>
        <li>Electrical Machines</li>
        <li>Power System Protection & Switchgears</li>
        <li>Tamil (Fluent) · English (Fluent)</li>
      </ul>
    </section>

    <section id="experience" class="card">
      <h2>Work Experience</h2>
      <ul>
        <li><strong>Trainee – PSG Industrial Institute</strong> (30 Weeks): Manufacturing, assembly and testing of induction motors and submersible pumps.</li>
        <li><strong>Intern – Salzer Electronics Ltd</strong> (May 2023): Assembly and testing of MCBs and MPCBs.</li>
        <li><strong>Intern – STEPS Knowledge Services Pvt Ltd</strong> (June–July 2023): Renewable energy and radar sensor applications.</li>
      </ul>
    </section>

    <section id="projects" class="card">
      <h2>Projects</h2>

      <article class="project">
        <h3>SPEED CONTROL OF THREE PHASE INDUCTION MOTOR USING IOT</h3>
        <p>Developed a real-time motor speed control system using ESP32 and IR2110 gate driver, integrated with the Blynk IoT platform for mobile-based control. Implemented analytic tuning and safety interlocks to ensure stable operation under variable inputs.</p>
        <p class="muted">Tech: ESP32, IR2110, Blynk, Power Electronics</p>
      </article>

      <article class="project">
        <h3>PEDAL POWER GENERATION</h3>
        <p>Converted mechanical energy from cycling into electrical energy using a DC generator and a PID-controlled buck converter; added battery storage and regulated output capable of charging phones and powering laptops.</p>
        <p class="muted">Tech: DC generator, PID control, power storage</p>
      </article>
    </section>

    <section id="certifications" class="card">
      <h2>Certifications</h2>
      <ul>
        <li>Graphical Programming Tools for Real-Time Applications — PSG College of Technology</li>
        <li>Electrical Energy Conservation and Management — PSG College of Technology & Ram Kalam Centre</li>
        <li>Industrial Finance and Taxation — PSG College of Technology & Manohar Chowdhry & Associates</li>
      </ul>
    </section>

    <section id="leadership" class="card">
      <h2>Leadership & Volunteering</h2>
      <ul>
        <li>Coordinator – IEEE SC 12951 "Srishti2k23": Managed hostel accommodations for tech fest.</li>
        <li>Organizer – LAPP CABLE Industrial Visit: Planned and executed student industry visit.</li>
      </ul>
    </section>
  </main>

  <footer class="site-footer" role="contentinfo">
    <div>
      <small>&copy; <span id="year"></span> Dinakar S — Built with care</small>
    </div>
  </footer>

  <script src="script.js" defer></script>
</body>
</html>
HTML

# -- styles.css
cat > styles.css <<'CSS'
:root{
  --bg:#f0f4f8;
  --card:#ffffff;
  --accent:#0059b3;
  --muted:#6b7280;
  --text:#0f1724;
  --radius:10px;
  --gap:20px;
  --max-width:960px;
  font-family: "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}

*{box-sizing:border-box}
html,body{height:100%;margin:0;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased}
a{color:var(--accent);text-decoration:none}
.skip-link{position:absolute;left:-999px;top:auto;width:1px;height:1px;overflow:hidden}
.skip-link:focus{left:10px;top:10px;width:auto;height:auto;background:#fff;padding:8px;border-radius:6px;box-shadow:0 2px 6px rgba(0,0,0,0.15)}

.site-header{background:linear-gradient(90deg,#003366 0%, #0059b3 100%);color:white;padding:26px 16px;border-bottom:4px solid rgba(0,0,0,0.06)}
.header-inner{max-width:var(--max-width);margin:0 auto;display:flex;gap:24px;align-items:center;justify-content:space-between}
.intro{max-width:60%}
.site-title{margin:0;font-size:28px;letter-spacing:0.2px}
.subtitle{margin:6px 0;font-weight:600}
.tagline{margin:0;color:rgba(255,255,255,0.9)}
.actions{margin-top:12px}
.btn{display:inline-block;padding:8px 14px;border-radius:8px;background:#fff;color:#003246;font-weight:700;border:0;text-decoration:none;cursor:pointer}
.btn:hover{filter:brightness(0.98)}
.btn.outline{background:transparent;color:rgba(255,255,255,0.95);border:1px solid rgba(255,255,255,0.15)}

.photo-wrap{width:180px;flex:0 0 180px}
.profile-photo{width:100%;height:auto;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,0.25);object-fit:cover}

/* Navigation */
.site-nav{background:transparent;border-top:1px solid rgba(255,255,255,0.03);padding:8px 0}
.site-nav ul{list-style:none;margin:0;padding:0;max-width:var(--max-width);margin:8px auto 0;display:flex;gap:12px}
.site-nav a{color:rgba(255,255,255,0.95);font-weight:600}

/* Main layout */
.site-main{max-width:var(--max-width);margin:28px auto;padding:0 16px}
.card{background:var(--card);padding:20px;border-radius:var(--radius);box-shadow:0 6px 18px rgba(15,23,36,0.06);margin-bottom:var(--gap)}
h2{color:#003366;margin-top:0}
.muted{color:var(--muted);font-size:14px}
.skills-list{display:flex;flex-wrap:wrap;gap:8px;padding-left:0;list-style:none}
.skills-list li{background:#f3f6fb;padding:8px 12px;border-radius:999px;color:var(--muted);font-weight:600}

/* Projects */
.project + .project{margin-top:12px}

/* Form */
#contact-form{display:grid;gap:10px;max-width:520px}
#contact-form label{font-weight:700;font-size:14px}
#contact-form input,#contact-form textarea{padding:10px;border:1px solid #e5e7eb;border-radius:8px;font-size:15px}
.form-actions{display:flex;gap:8px;margin-top:6px;align-items:center}

/* Footer */
.site-footer{text-align:center;padding:18px 16px;color:var(--muted)}

/* Responsive */
@media (max-width:900px){
  .header-inner{flex-direction:column;align-items:flex-start}
  .intro{max-width:100%}
  .photo-wrap{width:140px}
  .site-nav ul{flex-wrap:wrap}
}

@media (max-width:520px){
  .photo-wrap{display:none}
  .site-title{font-size:22px}
  .btn{padding:8px 10px}
}
CSS

# -- script.js
cat > script.js <<'JS'
// Basic scripts: populate year and handle the contact form by opening a mailto link.
// No server required. The form builds a mailto: URL and opens the user's mail client.

document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contact-form');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = encodeURIComponent(document.getElementById('name').value.trim());
    const email = encodeURIComponent(document.getElementById('email').value.trim());
    const message = encodeURIComponent(document.getElementById('message').value.trim());
    const subject = encodeURIComponent(`Portfolio contact from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${decodeURIComponent(message)}`);

    // Build mailto URL
    const mailto = `mailto:dinakarss666@gmail.com?subject=${subject}&body=${body}`;
    window.location.href = mailto;
  });
}

const fallbackBtn = document.getElementById('mailto-fallback');
if (fallbackBtn) {
  fallbackBtn.addEventListener('click', () => {
    // Opens blank new email with subject (same as above) using mailto
    const subject = encodeURIComponent('Contact from portfolio');
    window.location.href = `mailto:dinakarss666@gmail.com?subject=${subject}`;
  });
}
JS

# -- README.md
cat > README.md <<'MD'
# Dinakar S — Portfolio

This is a single-page, responsive portfolio for Dinakar S.

How to use:
1. Replace placeholders:
   - your-photo.jpg → add your portrait image file
   - resume.pdf → add your resume if you want the download link to work
   - LinkedIn / GitHub URL placeholders in index.html
2. Edit text (projects, experience) directly in index.html or inject from JSON if you prefer dynamic content.
3. Deploy:
   - GitHub Pages: create a repo (e.g., `dinakarss666/portfolio`), push files to main branch, enable Pages from Settings → Pages (source: main / root).
   - Vercel/Netlify: connect repo and deploy; these platforms auto-detect static sites.

Notes:
- Contact form opens the user's mail client (no backend). If you want a form that submits without exposing your email, I can integrate Formspree, Netlify Forms, or a serverless endpoint.
- I added ARIA landmarks and a skip link for accessibility, Open Graph metadata for richer link previews, and simple responsive styles.

Want me to:
- Create the GitHub repository and push these files for you (I can create repo name `portfolio` or another you choose)?
- Deploy this to GitHub Pages / Vercel and return the live URL?
- Convert this into a React/Next.js project with components and an easy data file for projects?
MD

# Optional: include placeholder files note
echo "NOTE: If you want a photo or resume included, place your-photo.jpg and resume.pdf into the folder before running the zip step."

# Create the zip
zip -r "../${ZIP_NAME}" . > /dev/null

cd ..

# Create base64 (single file). Try to use base64 --wrap=0 where available, fallback to openssl if needed.
if command -v base64 >/dev/null 2>&1; then
  if base64 --version >/dev/null 2>&1; then
    base64 --wrap=0 "$ZIP_NAME" > "$B64_NAME"
  else
    # macOS base64 may not support --wrap; use openssl if present, otherwise plain base64
    if command -v openssl >/dev/null 2>&1; then
      openssl base64 -in "$ZIP_NAME" -out "$B64_NAME" -A
    else
      base64 "$ZIP_NAME" > "$B64_NAME"
    fi
  fi
else
  # fallback
  openssl base64 -in "$ZIP_NAME" -out "$B64_NAME" -A
fi

echo
echo "Done."
echo "Created: $ZIP_NAME and $B64_NAME in the current directory."
echo
echo "To decode the base64 back into the zip:"
echo "  Linux:   base64 --decode ${B64_NAME} > ${ZIP_NAME}"
echo "  macOS:   openssl base64 -d -in ${B64_NAME} -out ${ZIP_NAME}"
echo "  Windows (PowerShell):"
echo "    [System.IO.File]::WriteAllBytes('${ZIP_NAME}', [Convert]::FromBase64String((Get-Content -Raw '${B64_NAME}')))"
echo
echo "Now upload ${ZIP_NAME} or ${B64_NAME} to GitHub (web UI) or use git to push the unzipped files."
chmod +x create_portfolio_zip.sh