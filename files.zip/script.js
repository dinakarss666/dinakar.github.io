// Basic scripts: populate year and handle the contact form by opening a mailto link.
// No server required. The form builds a mailto: URL and opens the user's mail client.

document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contact-form');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = encodeURIComponent(document.getElementById('name').value.trim());
    const email = encodeURIComponent(document.getElementById('email').value.trim());
    const message = encodeURIComponent(document.getElementById('message').value.trim());
    const subject = encodeURIComponent(`Portfolio contact from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${decodeURIComponent(message)}`);

    // Build mailto URL
    const mailto = `mailto:dinakarss666@gmail.com?subject=${subject}&body=${body}`;
    window.location.href = mailto;
  });
}

const fallbackBtn = document.getElementById('mailto-fallback');
if (fallbackBtn) {
  fallbackBtn.addEventListener('click', () => {
    // Opens blank new email with subject (same as above) using mailto
    const subject = encodeURIComponent('Contact from portfolio');
    window.location.href = `mailto:dinakarss666@gmail.com?subject=${subject}`;
  });
}