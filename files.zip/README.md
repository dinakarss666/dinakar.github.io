# Dinakar S — Portfolio

This is a single-page, responsive portfolio for Dinakar S.

How to use:
1. Replace placeholders:
   - your-photo.jpg → add your portrait image file
   - resume.pdf → add your resume if you want the download link to work
   - LinkedIn / GitHub URL placeholders in index.html
2. Edit text (projects, experience) directly in index.html or inject from JSON if you prefer dynamic content.
3. Deploy:
   - GitHub Pages: create a repo (e.g., `dinakarss666/portfolio`), push files to main branch, enable Pages from Settings → Pages (source: main / root).
   - Vercel/Netlify: connect repo and deploy; these platforms auto-detect static sites.

Notes:
- Contact form opens the user's mail client (no backend). If you want a form that submits without exposing your email, I can integrate Formspree, Netlify Forms, or a serverless endpoint.
- I added ARIA landmarks and a skip link for accessibility, Open Graph metadata for richer link previews, and simple responsive styles.

Want me to:
- Create the GitHub repository and push these files for you (I can create repo name `portfolio` or another you choose)?
- Deploy this to GitHub Pages / Vercel and return the live URL?
- Convert this into a React/Next.js project with components and an easy data file for projects?