# PowerShell script: run in a folder where you want the archive created
$dir = "portfolio-site"
$zip = "portfolio.zip"
$b64 = "$zip.b64"

Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $dir
New-Item -ItemType Directory -Path $dir | Out-Null

Set-Location $dir

@"
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dinakar S — Electrical Engineering Portfolio</title>
  ...
</html>
"@ > index.html
# (For brevity: repeat writing styles.css, script.js, README.md similarly or paste the full contents)
# After creating files, go up one level
Set-Location ..

Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($dir, $zip)

# Read bytes and convert to base64 string
$b = [IO.File]::ReadAllBytes($zip)
[IO.File]::WriteAllText($b64, [Convert]::ToBase64String($b))

Write-Host "Created $zip and $b64"
Write-Host "To decode in PowerShell:"
Write-Host "[System.IO.File]::WriteAllBytes('$zip',[Convert]::FromBase64String((Get-Content -Raw '$b64')))"